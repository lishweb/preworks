<?php get_header(); ?>
<main>

  <section class="page-hero"><span class="orb m soft" style="top:0;right:-60px;"></span><div class="wrap">
    <div class="bc"><a href="<?php echo home_url('/'); ?>">トップ</a> ／ よくある質問</div>
    <span class="eyebrow">FAQ</span><h1>よくある質問</h1><p class="sub">受講前によく聞かれる質問をまとめました。</p>
  </div></section>
  <section class="faq sec-pad"><div class="wrap"><div class="qa"><details><summary><span class="qi">Q</span>パソコンが苦手ですが大丈夫ですか？</summary><div class="a"><span class="ai">A</span>大丈夫です！基本操作から教えます。「メール・Web閲覧程度」ができれば問題ありません。</div></details><details><summary><span class="qi">Q</span>育児をしながらでも受講できますか？</summary><div class="a"><span class="ai">A</span>はい、受講できます。動画学習なので、お子様が寝ている時間やスキマ時間に進められます。面談時には、生活スタイルに合わせて最適なプランをご提案します。※2ヶ月プランの場合：1日2時間×週5日×7週間が目安です。</div></details><details><summary><span class="qi">Q</span>本当に実案件ができるようになりますか？</summary><div class="a"><span class="ai">A</span>はい、ただし、学習時間を確保し、課題にしっかり取り組むことが前提です。「なんとなく受講」では難しいです。本気で取り組む方には、確実に結果を出してもらいます。</div></details><details><summary><span class="qi">Q</span>受講までの流れを教えてください</summary><div class="a"><span class="ai">A</span>まずはLINEにご登録いただき、無料相談をお申し込みください。無料相談では、講座内容やプランの違い、受講開始までの流れを詳しくご案内します。</div></details><details><summary><span class="qi">Q</span>受講料はいくらですか？分割はできますか？</summary><div class="a"><span class="ai">A</span>2ヶ月プランは165,000円（税込）です。その他プランの料金・分割のご相談は、無料相談でご案内します。</div></details><details><summary><span class="qi">Q</span>卒業後、本当に仕事はありますか？</summary><div class="a"><span class="ai">A</span>修了試験と面接を通過した方には、運営会社LISHのオンライン秘書サービス「URAKATA」の実案件をご紹介します。修了生のお仕事獲得率は100%（2026年7月時点・修了生6名中6名）です。</div></details></div></div></section>
  <section class="finalcta sec-pad" id="contact"><div class="wrap">
    <span class="eyebrow" style="color:var(--gold)">Contact</span>
    <h2 class="mincho">「いつか在宅で働きたい」を、<br>今日から少しずつ形に。</h2>
    <p>無料相談では、未経験からオンライン秘書を始めた方の事例をもとに、<br>今のあなたが何から始めればよいのかを一緒に整理します。</p>
    <a class="btn btn-line" href="https://sub.online-assistant.biz/line/open/2sRcbvLGNaq8?mtid=BxzwhkkjSRAt" target="_blank" rel="noopener"><img src="<?php echo PREWORKS_IMG; ?>/LINE_Brand_icon.png" alt="LINE" class="liico">LINEで無料オンライン相談をする</a>
  </div></section>

</main>
<?php get_footer(); ?>
