<?php get_header(); ?>
<main>

  <section class="page-hero"><span class="orb m soft" style="top:0;right:-60px;"></span><div class="wrap">
    <div class="bc"><a href="<?php echo home_url('/'); ?>">トップ</a> ／ メンター紹介</div>
    <span class="eyebrow">Mentor</span><h1>伴走するのは、URAKATAの<br>現役メンバー</h1><p class="sub">オンライン秘書サービス「URAKATA」の実務メンバーが、1on1でサポートします。</p>
  </div></section>
  <section class="mentors sec-pad"><span class="orb m soft alt" style="top:40px;right:-100px;"></span><div class="wrap">
    <div class="mgrid"><a class="mcard reveal" href="<?php echo home_url('/mentor-1/'); ?>" style="text-decoration:none;"><img src="<?php echo PREWORKS_IMG; ?>/mentor-1.jpg" alt="仲宗根 偉子"><div class="mbody"><h3>仲宗根 偉子</h3><p class="m-attr">オンライン秘書歴：3年／40代／3児ママ</p><p>受講中の不安やつまずきにも寄り添いながら、一人ひとりのペースに合わせてサポートします。オンライン秘書として働くための一歩を、一緒に進んでいきましょう！</p><p class="mprof-link">プロフィールを見る →</p></div></a><a class="mcard reveal" href="<?php echo home_url('/mentor-2/'); ?>" style="text-decoration:none;"><img src="<?php echo PREWORKS_IMG; ?>/mentor-2.jpg" alt="髙松 由衣"><div class="mbody"><h3>髙松 由衣</h3><p class="m-attr">オンライン秘書歴：2年／30代／1児ママ</p><p>URAKATAのPR・広報を担当。「伝える力」の基本から、実務で使える形でお伝えします。</p><p class="mprof-link">プロフィールを見る →</p></div></a><a class="mcard reveal" href="<?php echo home_url('/mentor-3/'); ?>" style="text-decoration:none;"><img src="<?php echo PREWORKS_IMG; ?>/mentor-3.jpg" alt="戸田 あかね"><div class="mbody"><h3>戸田 あかね</h3><p class="m-attr">オンライン秘書歴：2年／30代／3児ママ</p><p>URAKATAのカスタマーサクセス担当。クライアント対応の勘所を、一緒に磨きます。</p><p class="mprof-link">プロフィールを見る →</p></div></a><a class="mcard reveal" href="<?php echo home_url('/mentor-4/'); ?>" style="text-decoration:none;"><img src="<?php echo PREWORKS_IMG; ?>/mentor-4.jpg" alt="玉木 達子"><div class="mbody"><h3>玉木 達子</h3><p class="m-attr">オンライン秘書歴：2年半／30代／3児ママ</p><p>URAKATAのコーディネートディレクター。案件と人をつなぐ視点で、あなたに合う進め方を一緒に考えます。</p><p class="mprof-link">プロフィールを見る →</p></div></a></div>
  </div></section>
  <section class="finalcta sec-pad" id="contact"><div class="wrap">
    <span class="eyebrow" style="color:var(--gold)">Contact</span>
    <h2 class="mincho">「いつか在宅で働きたい」を、<br>今日から少しずつ形に。</h2>
    <p>無料相談では、未経験からオンライン秘書を始めた方の事例をもとに、<br>今のあなたが何から始めればよいのかを一緒に整理します。</p>
    <a class="btn btn-line" href="https://sub.online-assistant.biz/line/open/2sRcbvLGNaq8?mtid=BxzwhkkjSRAt" target="_blank" rel="noopener"><img src="<?php echo PREWORKS_IMG; ?>/LINE_Brand_icon.png" alt="LINE" class="liico">LINEで無料オンライン相談をする</a>
  </div></section>

</main>
<?php get_footer(); ?>
