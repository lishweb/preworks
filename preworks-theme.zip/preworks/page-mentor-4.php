<?php get_header(); ?>
<main>

  <section class="page-hero"><span class="orb m soft" style="top:0;right:-60px;"></span><div class="wrap">
    <div class="bc"><a href="<?php echo home_url('/'); ?>">トップ</a> ／ <a href="<?php echo home_url('/mentor/'); ?>">メンター紹介</a> ／ 玉木 達子</div>
    <span class="eyebrow">Mentor</span><h1>メンター紹介</h1><p class="sub">オンライン秘書サービス「URAKATA」の現役メンバーが伴走します。</p>
  </div></section>
  <section class="message sec-pad"><div class="wrap mprofile reveal">
    <div class="mp-img"><img src="<?php echo PREWORKS_IMG; ?>/mentor-4.jpg" alt="玉木 達子"></div>
    <div class="mp-body">
      <span class="role">● URAKATA オペレーションユニット ／ コーディネートディレクター</span>
      <h2>玉木 達子</h2>
      <p class="m-attr">オンライン秘書歴：2年半／30代／3児ママ</p>
      <p class="catch">あなたに合う進め方を、<span class="mk">いっしょに。</span></p>
      <p>URAKATAで案件と秘書のマッチング・進行をディレクション。一人ひとりに合った無理のない関わり方を考え、現実的なペースで伴走します。</p>
      <p><strong>得意領域：</strong>案件コーディネート／スケジュール調整／オンボーディング支援</p>
    </div>
  </div>
    <div class="wrap center" style="margin-top:46px;"><a class="morelink" href="<?php echo home_url('/mentor/'); ?>">メンター紹介一覧へ戻る</a></div>
  </section>
  <section class="finalcta sec-pad" id="contact"><div class="wrap">
    <span class="eyebrow" style="color:var(--gold)">Contact</span>
    <h2 class="mincho">「いつか在宅で働きたい」を、<br>今日から少しずつ形に。</h2>
    <p>無料相談では、未経験からオンライン秘書を始めた方の事例をもとに、<br>今のあなたが何から始めればよいのかを一緒に整理します。</p>
    <a class="btn btn-line" href="https://sub.online-assistant.biz/line/open/2sRcbvLGNaq8?mtid=BxzwhkkjSRAt" target="_blank" rel="noopener"><img src="<?php echo PREWORKS_IMG; ?>/LINE_Brand_icon.png" alt="LINE" class="liico">LINEで無料オンライン相談をする</a>
  </div></section>

</main>
<?php get_footer(); ?>
