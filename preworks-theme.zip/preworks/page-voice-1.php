<?php get_header(); ?>
<main>

  <section class="page-hero"><span class="orb m soft" style="top:0;right:-60px;"></span><div class="wrap">
    <div class="bc"><a href="<?php echo home_url('/'); ?>">トップ</a> ／ <a href="<?php echo home_url('/voice/'); ?>">修了生の声</a> ／ 大城さん</div>
    <span class="eyebrow">Voice</span><h1>「私なんか」が、<br>変わった2ヶ月。</h1><p class="sub">大城さん（30代・2児ママ（6歳・0歳）｜前職：コールセンター業務）</p>
  </div></section>
  <section class="about sec-pad"><div class="wrap" style="max-width:840px;">
    <div class="reveal" style="margin-bottom:40px;position:relative;width:100%;padding-bottom:56.25%;height:0;border-radius:16px;overflow:hidden;box-shadow:0 18px 44px rgba(150,80,45,.14);background:#000;"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" src="https://www.youtube.com/embed/EhX5RDQ5Jfk" title="大城さんのインタビュー動画" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
    <div class="prose">
      <h2 class="reveal">受講のきっかけは？</h2><p class="reveal">「在宅ワーク 未経験」で検索しては、怪しい広告ばかりで閉じる毎日でした。preworksは現場を運営している会社が監修していると知って、ここなら本物かもしれないと思えたんです。</p><h2 class="reveal">学んでみて、いちばんの変化は？</h2><p class="reveal">在宅ワークのイメージが大きく変わりました。想像以上に責任感が求められる仕事だと実感しています。つまずいたとき、メンターさんがすぐ相談に乗ってくれたのが本当に支えでした。</p><h2 class="reveal">これから挑戦したい方へ。</h2><p class="reveal">「私なんか」が口ぐせだった私でも、名前で仕事をもらえるようになりました。0歩目からで大丈夫です。</p>
    </div>
  </div></section>
  <section class="finalcta sec-pad" id="contact"><div class="wrap">
    <span class="eyebrow" style="color:var(--gold)">Contact</span>
    <h2 class="mincho">「いつか在宅で働きたい」を、<br>今日から少しずつ形に。</h2>
    <p>無料相談では、未経験からオンライン秘書を始めた方の事例をもとに、<br>今のあなたが何から始めればよいのかを一緒に整理します。</p>
    <a class="btn btn-line" href="https://sub.online-assistant.biz/line/open/2sRcbvLGNaq8?mtid=BxzwhkkjSRAt" target="_blank" rel="noopener"><img src="<?php echo PREWORKS_IMG; ?>/LINE_Brand_icon.png" alt="LINE" class="liico">LINEで無料オンライン相談をする</a>
  </div></section>

</main>
<?php get_footer(); ?>
