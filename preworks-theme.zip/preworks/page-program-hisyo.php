<?php get_header(); ?>
<main>

  <section class="page-hero"><span class="orb m soft" style="top:0;right:-60px;"></span><div class="wrap">
    <div class="bc"><a href="<?php echo home_url('/'); ?>">トップ</a> ／ <a href="<?php echo home_url('/program/'); ?>">プログラム</a> ／ オンライン秘書講座</div>
    <span class="eyebrow">Online Secretary Course</span>
    <h1>最短2ヶ月で、<br>在宅オンライン秘書に。</h1>
    <p class="sub">実践型カリキュラム＋現役ママ秘書の1on1伴走＋修了後のURAKATA案件紹介。本業・育児に合わせて受講期間を選べます。</p>
  </div></section>

  <!-- 対象 -->
  <section class="worry sec-pad"><span class="orb m coral alt" style="top:-70px;right:-90px;"></span><div class="wrap">
    <div class="headblock"><div class="fukidashi">こんな方に向いています</div><h2 class="htitle">本気で、在宅へ。</h2><p class="subhead">「なんとなく」では結果は出ません。だからこそ、踏み出す人を全力で支えます。</p></div>
    <div class="wcards">
      <div class="wcard reveal"><div class="n">01</div><p>本業・育児と両立しながら、在宅スキルを今のうちに先取りしたい</p></div>
      <div class="wcard reveal"><div class="n">02</div><p>学んで終わりではなく、卒業後に仕事までつなげたい</p></div>
      <div class="wcard reveal"><div class="n">03</div><p>怪しい副業ではなく、現場で通用する実務を身につけたい</p></div>
      <div class="wcard reveal"><div class="n">04</div><p>1on1で相談しながら、挫折せず進めたい</p></div>
    </div>
  </div></section>

  <!-- カリキュラム 8モジュール -->
  <section class="program sec-pad"><div class="wrap">
    <div class="mod-head"><span class="nb">Curriculum</span><h2 class="htitle" style="margin-top:12px;">カリキュラム内容</h2><p class="prog-lead">各講座ごとに、実際の案件と同じ流れで実践課題の提出をいただきます。</p></div>
    <p class="prog-lead" style="margin-top:-8px;margin-bottom:22px;">各STEPをタップすると、Day（日）ごとの学習内容が開きます。</p>
    <div class="steplist reveal">
      <details class="stepacc" open>
        <summary><span class="stepno">STEP<b>1</b></span><span class="stepttl"><h4>自己理解・オンライン秘書の全体像</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>講座オリエンテーション＋オンライン秘書の仕事理解</h5><p>講座の進め方やサポート内容を確認し、オンライン秘書の仕事内容・働き方を理解します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>スキルの言語化と強みの発見</h5><p>これまでの経験や出来事を振り返り、自分の得意・好き・価値観を整理します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>在宅ワークの現実とマネープラン</h5><p>在宅ワークのメリット・デメリットや、収入の仕組みを理解します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>4</b></span><div class="daybody"><h5>理想の働き方を描く＋不安の言語化</h5><p>理想のライフスタイルや働き方を具体的にイメージし、今の不安や悩みを整理します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>5</b></span><div class="daybody"><h5>フリーランスの働き方・マインドセット・不安解消</h5><p>フリーランスとして必要な考え方や心構えを学び、よくある不安の解消法を知ります。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>6</b></span><div class="daybody"><h5>じぶんを守る法務基礎</h5><p>契約やトラブルを防ぐために必要な法律の基礎知識を学び、安心して働くための土台をつくります。</p></div></div>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>2</b></span><span class="stepttl"><h4>在宅ワーク基礎＋コミュニケーション基礎</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>在宅ワークの基本マナーと自己管理</h5><p>在宅ワーカーに必要なマインドセットと、時間・タスク管理の基本を身につけます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>チャットツールの基本操作</h5><p>Slack・Chatwork・Discordなど、実務で使う主要ツールの使い方を学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>「伝わる」報連相とビジネス文章</h5><p>オンラインでの報連相のコツと、読みやすい文章の書き方を練習します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>4</b></span><div class="daybody"><h5>クライアントとの信頼関係づくり</h5><p>期待値のすり合わせや、丁寧なコミュニケーションの型を学びます。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>3</b></span><span class="stepttl"><h4>ITリテラシー・AI基礎・Googleツール基礎</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>PC・オンラインワークの基礎</h5><p>効率よく働くためのPC操作・ショートカット・作業環境づくりを学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>Googleツール実務</h5><p>ドキュメント／スプレッドシート／カレンダーなど、実務で使うGoogle Workspaceの操作を身につけます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>生成AIの基本と業務活用</h5><p>ChatGPTなどの基本操作と、議事録・要約・メール下書きへの応用を学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>4</b></span><div class="daybody"><h5>情報収集・整理の効率化</h5><p>リサーチや情報整理を、ツール・AIで効率化する方法を学びます。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>4</b></span><span class="stepttl"><h4>バックオフィス基礎</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>事務作業の基本（請求書・経費精算）</h5><p>バックオフィス実務の基本と、正確に進めるコツを学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>データ入力・スプレッドシート管理</h5><p>効率的な入力とデータ管理の実践を行います。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>リサーチ業務の進め方</h5><p>目的に沿った情報収集と、成果物のまとめ方を学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>4</b></span><div class="daybody"><h5>ミスを防ぐチェックの習慣</h5><p>ダブルチェックや確認フローで、品質を保つ方法を身につけます。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>5</b></span><span class="stepttl"><h4>オンラインツール実践</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>タスク・プロジェクト管理</h5><p>Notion・Trelloなどで、タスクとスケジュールを管理する方法を学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>チームでの情報共有</h5><p>議事録・ファイル管理・共同編集など、チームワークの実践を行います。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>マニュアル作成と仕組み化</h5><p>手順書・マニュアルを作り、業務を仕組み化するスキルを身につけます。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>6</b></span><span class="stepttl"><h4>実務シミュレーション強化</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>実案件を想定した実践課題</h5><p>本番に近い流れで、実際の業務の進め方を体験します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>複数業務の並行管理</h5><p>優先順位づけと段取りで、複数タスクを回す練習をします。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>フィードバックと改善</h5><p>メンターの添削をもとに、改善のサイクルを回します。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
      <details class="stepacc">
        <summary><span class="stepno">STEP<b>7</b></span><span class="stepttl"><h4>スキルアップ＋案件獲得</h4><span class="steptags"><span class="stag">動画講座</span><span class="stag">実践ワーク</span><span class="stag">面接シミュレーション</span></span></span><span class="chev">▾</span></summary>
        <div class="stepdetail">
          <div class="dayrow"><span class="dayno">Day<b>1</b></span><div class="daybody"><h5>プロフィール・提案文の作成</h5><p>選ばれるプロフィールと、提案文の書き方を学びます。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>2</b></span><div class="daybody"><h5>面接シミュレーション・自己PR</h5><p>面接の受け答えと、自己PRの伝え方を練習します。</p></div></div>
          <div class="dayrow"><span class="dayno">Day<b>3</b></span><div class="daybody"><h5>修了試験〜案件紹介</h5><p>修了試験・面接を経て、URAKATAの案件紹介につなげます。</p></div></div>
          <p class="day-note">※Day構成は現在準備中の内容です（正式版に差し替え予定）。</p>
        </div>
      </details>
    </div>
  </div></section>

  <!-- 料金プラン -->
  <section class="pricing sec-pad"><div class="wrap">
    <div class="headblock"><span class="eyebrow">Plans</span><h2 class="htitle">受講期間プラン</h2><p class="subhead">本業・育児の状況に合わせて、2・3・6・12ヶ月から選べます。</p></div>
    <div class="plans">
      <div class="plan reveal"><div class="term">2<span class="u">ヶ月</span></div><div class="model">学習定着プラン</div><div class="price"><span class="ps-label">24回分割</span>約6,900<small>円/月</small></div><div class="price-lump">一括 165,000円（税込）</div></div>
      <div class="plan reveal"><div class="term">3<span class="u">ヶ月</span></div><div class="model">初案件チャレンジプラン</div><div class="price"><span class="ps-label">24回分割</span>約9,200<small>円/月</small></div><div class="price-lump">一括 220,000円（税込）</div></div>
      <div class="plan reco reveal"><span class="badge">おすすめ</span><div class="term">6<span class="u">ヶ月</span></div><div class="model">自走化サポートプラン</div><div class="price"><span class="ps-label">24回分割</span>約16,100<small>円/月</small></div><div class="price-lump">一括 385,000円（税込）</div></div>
      <div class="plan reveal"><div class="term">12<span class="u">ヶ月</span></div><div class="model">完全自立サポートプラン</div><div class="price"><span class="ps-label">24回分割</span>約27,500<small>円/月</small></div><div class="price-lump">一括 660,000円（税込）</div></div>
    </div>
    <p class="slider-hint">← 横にスワイプして他のプランを見る →</p>
    <p class="prog-note">※受講料とは別に、入会金 55,000円（税込）が全プラン一律でかかります。<br>お支払い方法：銀行振込＝一括払いのみ／クレジットカード＝分割払い可（分割手数料はお客様のご負担）。</p>
  </div></section>

  <!-- 受講の流れ -->
  <section class="reasons sec-pad"><div class="wrap">
    <div class="headblock left reveal"><span class="eyebrow">Steps</span><h2 class="htitle">無料相談から、<span class="mk">初仕事まで。</span></h2></div>
    <div class="rlist">
      <div class="ritem reveal"><div class="num mincho">01</div><div><h3>LINEで無料相談</h3><p>気になることを、まず気軽に。勧誘はしません。</p></div></div>
      <div class="ritem reveal"><div class="num mincho">02</div><div><h3>無料説明会</h3><p>内容と料金を確認。合わなければ申し込まなくてOKです。</p></div></div>
      <div class="ritem reveal"><div class="num mincho">03</div><div><h3>受講・実務練習</h3><p>2ヶ月の実務直結カリキュラム＋1on1サポートで、手を動かして身につけます。</p></div></div>
      <div class="ritem reveal"><div class="num mincho">04</div><div><h3>修了試験＋面接</h3><p>通過した方に、URAKATAの実案件をご紹介します。</p></div></div>
      <div class="ritem reveal"><div class="num mincho">05</div><div><h3>初仕事・稼働スタート</h3><p>実際の案件で稼働をスタート。ここがゴールではなく出口です。</p></div></div>
    </div>
  </div></section>

  <section class="finalcta sec-pad" id="contact"><div class="wrap">
    <span class="eyebrow" style="color:var(--gold)">Contact</span>
    <h2 class="mincho">「いつか在宅で働きたい」を、<br>今日から少しずつ形に。</h2>
    <p>無料相談では、未経験からオンライン秘書を始めた方の事例をもとに、<br>今のあなたが何から始めればよいのかを一緒に整理します。</p>
    <a class="btn btn-line" href="https://sub.online-assistant.biz/line/open/2sRcbvLGNaq8?mtid=BxzwhkkjSRAt" target="_blank" rel="noopener"><img src="<?php echo PREWORKS_IMG; ?>/LINE_Brand_icon.png" alt="LINE" class="liico">LINEで無料オンライン相談をする</a>
  </div></section>

</main>
<?php get_footer(); ?>
